package com.contact.servlet;

import com.contact.dao.ContactDAO;
import com.contact.model.Contact;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/contacts")
public class ContactServlet extends HttpServlet {

    private ContactDAO contactDAO = new ContactDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {

            case "list":
                listContacts(request, response);
                break;

            case "showAdd":
                request.getRequestDispatcher("/addContact.jsp").forward(request, response);
                break;

            case "showEdit":
                showEditForm(request, response);
                break;

            case "delete":
                deleteContact(request, response);
                break;

            default:
                listContacts(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) action = "";

        switch (action) {

            case "add":
                addContact(request, response);
                break;

            case "edit":
                updateContact(request, response);
                break;

            default:
                listContacts(request, response);
        }
    }

    // ── LIST ──────────────────────────────────────────────────────────────────
    private void listContacts(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Contact> contacts = contactDAO.getAllContacts();
        request.setAttribute("contacts", contacts);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/viewContacts.jsp");
        dispatcher.forward(request, response);
    }

    // ── ADD ───────────────────────────────────────────────────────────────────
    private void addContact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name    = request.getParameter("name");
        String email   = request.getParameter("email");
        String phone   = request.getParameter("phone");
        String address = request.getParameter("address");

        // Basic validation
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            phone == null || phone.trim().isEmpty()) {

            request.setAttribute("errorMessage", "Name, Email, and Phone are required fields!");
            request.getRequestDispatcher("/addContact.jsp").forward(request, response);
            return;
        }

        Contact contact = new Contact();
        contact.setName(name.trim());
        contact.setEmail(email.trim());
        contact.setPhone(phone.trim());
        contact.setAddress(address != null ? address.trim() : "");

        boolean success = contactDAO.addContact(contact);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/contacts?action=list&successMessage=Contact+added+successfully!");
        } else {
            request.setAttribute("errorMessage", "Failed to add contact. Please try again.");
            request.getRequestDispatcher("/addContact.jsp").forward(request, response);
        }
    }

    // ── SHOW EDIT FORM ────────────────────────────────────────────────────────
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        Contact contact = contactDAO.getContactById(id);

        if (contact == null) {
            response.sendRedirect(request.getContextPath() + "/contacts?action=list&errorMessage=Contact+not+found!");
            return;
        }

        request.setAttribute("contact", contact);
        request.getRequestDispatcher("/editContact.jsp").forward(request, response);
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    private void updateContact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int    id      = Integer.parseInt(request.getParameter("id"));
        String name    = request.getParameter("name");
        String email   = request.getParameter("email");
        String phone   = request.getParameter("phone");
        String address = request.getParameter("address");

        // Basic validation
        if (name == null || name.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            phone == null || phone.trim().isEmpty()) {

            Contact contact = contactDAO.getContactById(id);
            request.setAttribute("contact", contact);
            request.setAttribute("errorMessage", "Name, Email, and Phone are required fields!");
            request.getRequestDispatcher("/editContact.jsp").forward(request, response);
            return;
        }

        Contact contact = new Contact();
        contact.setId(id);
        contact.setName(name.trim());
        contact.setEmail(email.trim());
        contact.setPhone(phone.trim());
        contact.setAddress(address != null ? address.trim() : "");

        boolean success = contactDAO.updateContact(contact);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/contacts?action=list&successMessage=Contact+updated+successfully!");
        } else {
            request.setAttribute("contact", contact);
            request.setAttribute("errorMessage", "Failed to update contact. Please try again.");
            request.getRequestDispatcher("/editContact.jsp").forward(request, response);
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    private void deleteContact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        boolean success = contactDAO.deleteContact(id);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/contacts?action=list&successMessage=Contact+deleted+successfully!");
        } else {
            response.sendRedirect(request.getContextPath() + "/contacts?action=list&errorMessage=Failed+to+delete+contact!");
        }
    }
}
