package com.contact.dao;

import com.contact.model.Contact;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactDAO {

    // In-memory storage (static so data persists across requests in the same session)
    private static Map<Integer, Contact> contactMap = new HashMap<>();
    private static int idCounter = 1;

    // Pre-load some sample contacts so Sprint 2 "view previous contacts" works
    static {
        contactMap.put(idCounter, new Contact(idCounter++, "Alice Johnson", "alice@example.com", "9876543210", "Chennai"));
        contactMap.put(idCounter, new Contact(idCounter++, "Bob Smith",    "bob@example.com",   "9123456780", "Bangalore"));
    }

    // ── CREATE ────────────────────────────────────────────────────────────────
    public boolean addContact(Contact contact) {
        try {
            contact.setId(idCounter);
            contactMap.put(idCounter, contact);
            idCounter++;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ── READ ALL ──────────────────────────────────────────────────────────────
    public List<Contact> getAllContacts() {
        return new ArrayList<>(contactMap.values());
    }

    // ── READ ONE ──────────────────────────────────────────────────────────────
    public Contact getContactById(int id) {
        return contactMap.get(id);
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────
    public boolean updateContact(Contact contact) {
        if (contactMap.containsKey(contact.getId())) {
            contactMap.put(contact.getId(), contact);
            return true;
        }
        return false;
    }

    // ── DELETE ────────────────────────────────────────────────────────────────
    public boolean deleteContact(int id) {
        if (contactMap.containsKey(id)) {
            contactMap.remove(id);
            return true;
        }
        return false;
    }
}
