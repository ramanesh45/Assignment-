<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Redirect to contacts list on app start
    response.sendRedirect(request.getContextPath() + "/contacts?action=list");
%>
