<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Manager - Edit Contact</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            color: #333;
        }

        header {
            background: #2c3e50;
            color: white;
            padding: 16px 32px;
        }
        header h1 { font-size: 1.5rem; }

        .container {
            max-width: 550px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 32px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .card h2 { margin-bottom: 24px; color: #2c3e50; }

        .form-group { margin-bottom: 18px; }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.2s;
        }

        input:focus {
            outline: none;
            border-color: #f39c12;
            box-shadow: 0 0 0 3px rgba(243,156,18,0.15);
        }

        .btn {
            padding: 10px 22px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
            text-decoration: none;
            display: inline-block;
        }
        .btn-warning  { background: #f39c12; color: white; }
        .btn-secondary { background: #95a5a6; color: white; margin-left: 10px; }
        .btn-warning:hover  { background: #d68910; }
        .btn-secondary:hover { background: #7f8c8d; }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .required { color: red; }
    </style>
</head>
<body>

<header>
    <h1>📒 Contact Manager</h1>
</header>

<div class="container">
    <div class="card">
        <h2>✏️ Edit Contact</h2>

        <%-- Error Message --%>
        <c:if test="${not empty errorMessage}">
            <div class="alert-danger">❌ ${errorMessage}</div>
        </c:if>

        <form action="${pageContext.request.contextPath}/contacts" method="post">
            <input type="hidden" name="action" value="edit" />
            <input type="hidden" name="id"     value="${contact.id}" />

            <div class="form-group">
                <label>Name <span class="required">*</span></label>
                <input type="text" name="name" placeholder="Enter full name"
                       value="${contact.name}" required />
            </div>

            <div class="form-group">
                <label>Email <span class="required">*</span></label>
                <input type="email" name="email" placeholder="Enter email address"
                       value="${contact.email}" required />
            </div>

            <div class="form-group">
                <label>Phone <span class="required">*</span></label>
                <input type="text" name="phone" placeholder="Enter phone number"
                       value="${contact.phone}" required />
            </div>

            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" placeholder="Enter address (optional)"
                       value="${contact.address}" />
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-warning">🔄 Update Contact</button>
                <a href="${pageContext.request.contextPath}/contacts?action=list"
                   class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
