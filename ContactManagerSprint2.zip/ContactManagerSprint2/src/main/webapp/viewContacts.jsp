<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt"  prefix="fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Manager - All Contacts</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            color: #333;
        }

        header {
            background: #2c3e50;
            color: white;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 { font-size: 1.5rem; }

        .btn {
            padding: 8px 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary   { background: #3498db; color: white; }
        .btn-warning   { background: #f39c12; color: white; }
        .btn-danger    { background: #e74c3c; color: white; }
        .btn-primary:hover { background: #2980b9; }
        .btn-warning:hover { background: #d68910; }
        .btn-danger:hover  { background: #c0392b; }

        .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }

        .alert {
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger  { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        thead { background: #2c3e50; color: white; }
        th, td { padding: 14px 16px; text-align: left; }
        tbody tr:nth-child(even)  { background: #f8f9fa; }
        tbody tr:hover { background: #eaf2ff; }

        .actions { display: flex; gap: 8px; }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #888;
            font-size: 1.1rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<header>
    <h1>📒 Contact Manager</h1>
    <a href="${pageContext.request.contextPath}/contacts?action=showAdd" class="btn btn-primary">+ Add New Contact</a>
</header>

<div class="container">

    <%-- Success Message (from redirect param) --%>
    <c:if test="${not empty param.successMessage}">
        <div class="alert alert-success">
            ✅ ${param.successMessage}
        </div>
    </c:if>

    <%-- Error Message (from redirect param) --%>
    <c:if test="${not empty param.errorMessage}">
        <div class="alert alert-danger">
            ❌ ${param.errorMessage}
        </div>
    </c:if>

    <%-- Contacts Table --%>
    <c:choose>
        <c:when test="${not empty contacts}">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="contact" items="${contacts}" varStatus="status">
                        <tr>
                            <td>${status.count}</td>
                            <td>${contact.name}</td>
                            <td>${contact.email}</td>
                            <td>${contact.phone}</td>
                            <td>${contact.address}</td>
                            <td class="actions">
                                <a href="${pageContext.request.contextPath}/contacts?action=showEdit&id=${contact.id}"
                                   class="btn btn-warning">Edit</a>
                                <a href="${pageContext.request.contextPath}/contacts?action=delete&id=${contact.id}"
                                   class="btn btn-danger"
                                   onclick="return confirm('Are you sure you want to delete this contact?');">Delete</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </c:when>
        <c:otherwise>
            <div class="no-data">
                No contacts found. <a href="${pageContext.request.contextPath}/contacts?action=showAdd">Add your first contact!</a>
            </div>
        </c:otherwise>
    </c:choose>

</div>
</body>
</html>
