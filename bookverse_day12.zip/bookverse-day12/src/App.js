import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import BookDetailPage from './pages/BookDetailPage';
import NotFoundPage from './pages/NotFoundPage';

// ── Render Props component: provides greeting text ──────────────────────────
// A component that uses "render prop" pattern to share greeting logic
export function UserGreeting({ render }) {
  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? '☀️ Good morning' :
    hour < 17 ? '👋 Good afternoon' :
                '🌙 Good evening';
  return render(greeting);
}

function App() {
  const location = useLocation();

  return (
    <>
      <Navbar />
      <TransitionGroup component={null}>
        <CSSTransition
          key={location.pathname}
          classNames="page"
          timeout={300}
          unmountOnExit
        >
          <div>
            <Routes location={location}>
              <Route path="/"          element={<HomePage />} />
              <Route path="/book/:id"  element={<BookDetailPage />} />
              <Route path="*"          element={<NotFoundPage />} />
            </Routes>
          </div>
        </CSSTransition>
      </TransitionGroup>

      <footer className="bv-footer">
        BookVerse · Day 12: Routing &amp; Backend Integration · Great Learning
      </footer>
    </>
  );
}

export default App;
