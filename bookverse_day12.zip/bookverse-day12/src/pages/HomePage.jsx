import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BookList from '../components/BookList';
import StatusBanner from '../components/StatusBanner';
import withLoader from '../components/withLoader';

// Apply HOC to BookList
const BookListWithLoader = withLoader(BookList);

function HomePage() {
  const [books,   setBooks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);
  const [search,  setSearch]  = useState('');

  // Fetch books from json-server via axios
  useEffect(() => {
    axios.get('/books')
      .then(res => {
        setBooks(res.data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message || 'Network error');
        setLoading(false);
      });
  }, []);

  const filtered = books.filter(b =>
    b.title.toLowerCase().includes(search.toLowerCase()) ||
    b.author.toLowerCase().includes(search.toLowerCase()) ||
    b.genre.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      {/* Hero */}
      <div className="bv-hero">
        <h1>Discover Books & Authors</h1>
        <p>Click any card to explore full details</p>

        {/* Search bar */}
        <div style={{ marginTop: '1.4rem', display: 'flex', justifyContent: 'center' }}>
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by title, author or genre…"
            style={{
              padding: '.55rem 1.2rem',
              borderRadius: 8,
              border: 'none',
              width: 320,
              fontFamily: 'Inter, sans-serif',
              fontSize: '.95rem',
              outline: 'none',
            }}
          />
        </div>
      </div>

      <main className="bv-main">
        {/* ── Render Props: StatusBanner ── */}
        {!loading && !error && (
          <StatusBanner
            bookCount={books.length}
            render={({ greeting, message }) => (
              <div className="greeting-banner">
                <span>{greeting}</span>
                <span style={{ color: '#555', fontWeight: 400 }}>—</span>
                <span>{message}</span>
              </div>
            )}
          />
        )}

        <h2 className="bv-section-title">Browse Books</h2>

        {/* ── HOC: shows spinner/error automatically ── */}
        <BookListWithLoader
          isLoading={loading}
          error={error}
          books={filtered}
        />
      </main>
    </>
  );
}

export default HomePage;
