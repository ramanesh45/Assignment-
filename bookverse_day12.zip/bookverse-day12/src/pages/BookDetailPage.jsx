import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import withLoader from '../components/withLoader';

// ── A simple detail view wrapped by HOC ──────────────────────────────────────
function BookDetail({ book }) {
  const stars = '★'.repeat(book.rating) + '☆'.repeat(5 - book.rating);

  return (
    <>
      {/* Hero */}
      <div className="detail-hero">
        <div className="container" style={{ maxWidth: 800 }}>
          <Link to="/" className="back-btn">← Back to Library</Link>
          <span className="detail-emoji">{book.emoji}</span>
          <h1 className="detail-title">{book.title}</h1>
          <div className="detail-author">by {book.author}</div>
          <div className="detail-meta" style={{ marginTop: '.8rem' }}>
            <span>{book.genre}</span>
            <span>{book.year}</span>
            <span>{book.pages} pages</span>
            <span className="stars">{stars}</span>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="detail-body">
        <div className="detail-info-card">
          <h3>📖 About this Book</h3>
          <p className="detail-desc">{book.description}</p>
        </div>

        <div className="detail-info-card">
          <h3>📋 Book Information</h3>
          {[
            ['Author',    book.author],
            ['Genre',     book.genre],
            ['Published', book.year],
            ['Pages',     book.pages],
            ['Publisher', book.publisher],
            ['ISBN',      book.isbn],
          ].map(([label, value]) => (
            <div className="detail-info-row" key={label}>
              <span className="label">{label}</span>
              <span className="value">{value}</span>
            </div>
          ))}
        </div>

        <Link to="/" className="back-btn">← Back to Library</Link>
      </div>
    </>
  );
}

// Wrap with HOC for loading/error states
const BookDetailWithLoader = withLoader(BookDetail);

// ── Page component – uses useParams ──────────────────────────────────────────
function BookDetailPage() {
  const { id }    = useParams();
  const [book,    setBook]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);

    axios.get(`/books/${id}`)
      .then(res => {
        setBook(res.data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.response?.status === 404
          ? 'Book not found.'
          : err.message || 'Network error');
        setLoading(false);
      });
  }, [id]);

  return (
    <BookDetailWithLoader
      isLoading={loading}
      error={error}
      book={book}
    />
  );
}

export default BookDetailPage;
