import React from 'react';
import { Link } from 'react-router-dom';

function NotFoundPage() {
  return (
    <div style={{ textAlign: 'center', padding: '6rem 1rem' }}>
      <div style={{ fontSize: '5rem', marginBottom: '1rem' }}>📚</div>
      <h1 style={{ fontFamily: 'var(--font-disp)', fontSize: '2.5rem', color: 'var(--ink)' }}>
        404 – Page Not Found
      </h1>
      <p style={{ color: '#888', margin: '1rem 0 1.5rem' }}>
        This page doesn't exist in our library.
      </p>
      <Link to="/" className="back-btn" style={{ display: 'inline-flex' }}>
        ← Back to Home
      </Link>
    </div>
  );
}

export default NotFoundPage;
