import React from 'react';
import { Link, NavLink } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="bv-nav">
      <Link to="/" className="bv-nav__brand">
        Book<span>Verse</span>
      </Link>
      <div className="bv-nav__links">
        <NavLink to="/" end>Home</NavLink>
        <a href="http://localhost:3001/books" target="_blank" rel="noreferrer">
          API (json-server)
        </a>
      </div>
    </nav>
  );
}

export default Navbar;
