import React from 'react';
import PropTypes from 'prop-types';

/**
 * StatusBanner – Render Props Component
 * Provides dynamic status/greeting data via a render prop.
 * The parent decides HOW to render; this component provides WHAT data.
 *
 * Usage:
 *   <StatusBanner
 *     bookCount={6}
 *     render={({ greeting, message }) => (
 *       <div>{greeting} — {message}</div>
 *     )}
 *   />
 */
function StatusBanner({ bookCount, render }) {
  const hour      = new Date().getHours();
  const greeting  =
    hour < 12 ? '☀️ Good morning, reader!'  :
    hour < 17 ? '👋 Good afternoon, reader!' :
                '🌙 Good evening, reader!';
  const message = `${bookCount} book${bookCount !== 1 ? 's' : ''} available in the library`;

  return render({ greeting, message });
}

StatusBanner.propTypes = {
  bookCount: PropTypes.number.isRequired,
  render:    PropTypes.func.isRequired,
};

export default StatusBanner;
