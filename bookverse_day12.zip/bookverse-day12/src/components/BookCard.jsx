import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function BookCard({ book }) {
  const stars = '★'.repeat(book.rating) + '☆'.repeat(5 - book.rating);

  return (
    <Link to={`/book/${book.id}`} className="book-card">
      <div className="book-card__cover" style={{ background: book.color }}>
        {book.emoji}
      </div>
      <div className="book-card__body">
        <div className="book-card__genre">{book.genre}</div>
        <div className="book-card__title">{book.title}</div>
        <div className="book-card__author">by {book.author}</div>
        <div className="book-card__rating">{stars}</div>
        <span className="book-card__btn">View Details →</span>
      </div>
    </Link>
  );
}

// PropTypes validation
BookCard.propTypes = {
  book: PropTypes.shape({
    id:          PropTypes.number.isRequired,
    title:       PropTypes.string.isRequired,
    author:      PropTypes.string.isRequired,
    genre:       PropTypes.string.isRequired,
    emoji:       PropTypes.string.isRequired,
    color:       PropTypes.string.isRequired,
    rating:      PropTypes.number.isRequired,
    description: PropTypes.string,
    year:        PropTypes.number,
    pages:       PropTypes.number,
    publisher:   PropTypes.string,
    isbn:        PropTypes.string,
  }).isRequired,
};

export default BookCard;
