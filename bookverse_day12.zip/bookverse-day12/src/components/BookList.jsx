import React from 'react';
import PropTypes from 'prop-types';
import BookCard from './BookCard';

function BookList({ books }) {
  if (books.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', color: '#aaa' }}>
        <div style={{ fontSize: '3rem', marginBottom: '.5rem' }}>📭</div>
        <p>No books found.</p>
      </div>
    );
  }

  return (
    <div className="row g-3">
      {books.map(book => (
        <div className="col-12 col-sm-6 col-md-4 col-lg-3" key={book.id}>
          <BookCard book={book} />
        </div>
      ))}
    </div>
  );
}

BookList.propTypes = {
  books: PropTypes.array.isRequired,
};

export default BookList;
