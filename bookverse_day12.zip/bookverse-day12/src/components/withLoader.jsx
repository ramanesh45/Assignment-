import React from 'react';

/**
 * withLoader – Higher Order Component (HOC)
 * Wraps any component and shows a spinner while `isLoading` is true.
 * Usage: const BookListWithLoader = withLoader(BookList);
 *        <BookListWithLoader isLoading={loading} books={books} />
 */
function withLoader(WrappedComponent) {
  function WithLoaderComponent({ isLoading, error, ...rest }) {
    if (isLoading) {
      return (
        <div className="spinner-wrapper">
          <div className="spinner-ring" />
          <span style={{ color: '#16697a', fontWeight: 500 }}>
            Loading books…
          </span>
        </div>
      );
    }

    if (error) {
      return (
        <div className="error-box">
          <div style={{ fontSize: '2rem', marginBottom: '.5rem' }}>⚠️</div>
          <strong>Failed to load data</strong>
          <p style={{ marginTop: '.4rem', fontSize: '.9rem' }}>{error}</p>
          <p style={{ marginTop: '.6rem', fontSize: '.82rem', color: '#888' }}>
            Make sure json-server is running:&nbsp;
            <code>npm run server</code>
          </p>
        </div>
      );
    }

    return <WrappedComponent {...rest} />;
  }

  // Give the HOC a helpful display name for React DevTools
  WithLoaderComponent.displayName =
    `withLoader(${WrappedComponent.displayName || WrappedComponent.name || 'Component'})`;

  return WithLoaderComponent;
}

export default withLoader;
