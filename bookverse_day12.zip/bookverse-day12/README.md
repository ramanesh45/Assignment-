# BookVerse – Day 12: Routing & Backend Integration

## 🚀 How to Run

### 1. Install dependencies
```bash
npm install
npm install react-transition-group   # for page fade transitions
```

### 2. Start json-server (mock backend) – Terminal 1
```bash
npm run server
# Runs on http://localhost:3001
# API: http://localhost:3001/books
```

### 3. Start React app – Terminal 2
```bash
npm start
# Runs on http://localhost:3000
```

> The `package.json` has `"proxy": "http://localhost:3001"` so axios calls to `/books` automatically route to json-server.

---

## 📁 Project Structure

```
bookverse-day12/
├── books.json                        ← json-server mock database
├── package.json
├── public/
│   └── index.html
└── src/
    ├── index.js                      ← Entry point (BrowserRouter)
    ├── index.css                     ← Global styles + page transitions
    ├── App.js                        ← Routes + TransitionGroup (fade)
    ├── components/
    │   ├── Navbar.jsx                ← NavLink active styling
    │   ├── BookCard.jsx              ← PropTypes validated card
    │   ├── BookList.jsx              ← Composable list wrapper
    │   ├── withLoader.jsx            ← HOC: loading spinner / error
    │   └── StatusBanner.jsx          ← Render Props component
    └── pages/
        ├── HomePage.jsx              ← Fetches all books via axios
        ├── BookDetailPage.jsx        ← useParams → fetch by id
        └── NotFoundPage.jsx          ← 404 fallback
```

---

## ✅ Acceptance Criteria Coverage

| Requirement | File |
|---|---|
| `json-server` mock backend | `books.json` + `npm run server` |
| Fetch data with `axios` | `HomePage.jsx`, `BookDetailPage.jsx` |
| React Router (`BrowserRouter`, `Routes`, `Link`, `useParams`) | `index.js`, `App.js`, `BookDetailPage.jsx` |
| Route transitions (CSS fade in/out) | `App.js` + `TransitionGroup` + `index.css` |
| HOC for loading spinner | `src/components/withLoader.jsx` |
| Render Props (greeting + status) | `src/components/StatusBanner.jsx` |

---

## 🛠 Technical Focus Covered
- React Router v6: `BrowserRouter`, `Routes`, `Route`, `Link`, `NavLink`, `useParams`
- Routing transitions via `react-transition-group`
- json-server integration with CRA proxy
- Higher Order Components (HOC)
- Render Props pattern
