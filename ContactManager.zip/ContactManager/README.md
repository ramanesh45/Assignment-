# Contact Manager - Sprint 1

A Java Servlet web application to manage contacts efficiently.

## Project Structure

```
ContactManager/
├── pom.xml
└── src/
    └── main/
        ├── java/com/contactmanager/
        │   ├── model/
        │   │   └── Contact.java          # POJO model
        │   └── servlet/
        │       ├── AddContactServlet.java    # Handles GET (form) & POST (save)
        │       ├── ViewContactsServlet.java  # Lists all contacts
        │       └── DeleteContactServlet.java # Deletes a contact by ID
        └── webapp/
            ├── index.jsp           # Welcome page
            ├── addContact.jsp      # Add contact form
            ├── viewContacts.jsp    # View all contacts
            ├── css/
            │   └── style.css
            └── WEB-INF/
                └── web.xml
```

## How to Run

### Prerequisites
- JDK 17+
- Maven 3.8+
- Apache Tomcat 10+

### Steps

1. **Build the WAR file:**
   ```bash
   cd ContactManager
   mvn clean package
   ```

2. **Deploy to Tomcat:**
   - Copy `target/ContactManager.war` to Tomcat's `webapps/` folder
   - Start Tomcat: `bin/startup.sh` (Linux/Mac) or `bin/startup.bat` (Windows)

3. **Open in browser:**
   ```
   http://localhost:8080/ContactManager/
   ```

## Features

| Feature              | URL                        | Method |
|---------------------|----------------------------|--------|
| Welcome Page         | `/`                        | GET    |
| Show Add Form        | `/addContact`              | GET    |
| Save Contact         | `/addContact`              | POST   |
| View All Contacts    | `/viewContacts`            | GET    |
| Delete Contact       | `/deleteContact?id={id}`   | GET    |

## Storage

Contacts are stored in an `ArrayList<Contact>` held in `ServletContext`
(application scope), shared across all sessions during server uptime.
