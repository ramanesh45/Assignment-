package com.contactmanager.servlet;

import com.contactmanager.model.Contact;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/viewContacts")
public class ViewContactsServlet extends HttpServlet {

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Contact> contacts =
                (List<Contact>) getServletContext().getAttribute("contacts");

        if (contacts == null) {
            contacts = new ArrayList<>();
        }

        request.setAttribute("contacts", contacts);
        request.getRequestDispatcher("/viewContacts.jsp").forward(request, response);
    }
}
