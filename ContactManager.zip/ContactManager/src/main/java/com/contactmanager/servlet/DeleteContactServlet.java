package com.contactmanager.servlet;

import com.contactmanager.model.Contact;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/deleteContact")
public class DeleteContactServlet extends HttpServlet {

    @Override
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        List<Contact> contacts =
                (List<Contact>) getServletContext().getAttribute("contacts");

        if (contacts != null) {
            contacts.removeIf(c -> c.getId() == id);
        }

        response.sendRedirect(request.getContextPath() + "/viewContacts");
    }
}
