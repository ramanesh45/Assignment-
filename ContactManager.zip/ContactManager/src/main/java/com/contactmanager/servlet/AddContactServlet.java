package com.contactmanager.servlet;

import com.contactmanager.model.Contact;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/addContact")
public class AddContactServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Show the add contact form
        request.getRequestDispatcher("/addContact.jsp").forward(request, response);
    }

    @Override
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name     = request.getParameter("name");
        String phone    = request.getParameter("phone");
        String email    = request.getParameter("email");
        String category = request.getParameter("category");

        // Retrieve shared contacts list from ServletContext (application scope)
        List<Contact> contacts =
                (List<Contact>) getServletContext().getAttribute("contacts");

        if (contacts == null) {
            contacts = new ArrayList<>();
            getServletContext().setAttribute("contacts", contacts);
        }

        int newId = contacts.size() + 1;
        Contact contact = new Contact(newId, name, phone, email, category);
        contacts.add(contact);

        // Redirect to view all contacts after saving
        response.sendRedirect(request.getContextPath() + "/viewContacts");
    }
}
