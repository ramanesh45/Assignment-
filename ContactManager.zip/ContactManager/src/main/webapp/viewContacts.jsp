<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.contactmanager.model.Contact" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>All Contacts - Contact Manager</title>
  <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<nav>
  <div class="logo">&#128203; Contact<span>Manager</span></div>
  <div>
    <a class="btn btn-outline btn-sm" href="${pageContext.request.contextPath}/">Home</a>
    <a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/addContact">&#10133; Add New</a>
  </div>
</nav>

<div class="list-page">

  <div class="list-header">
    <h2>All Contacts
      <%
        List<Contact> contacts = (List<Contact>) request.getAttribute("contacts");
        int count = (contacts != null) ? contacts.size() : 0;
      %>
      <span class="badge"><%= count %></span>
    </h2>
    <a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/addContact">&#10133; Add New</a>
  </div>

  <%
    if (contacts == null || contacts.isEmpty()) {
  %>
    <div class="empty-state">
      <div class="icon">&#128229;</div>
      <p>No contacts yet. <a href="${pageContext.request.contextPath}/addContact">Add your first contact!</a></p>
    </div>
  <%
    } else {
      for (Contact c : contacts) {
        String initial = String.valueOf(c.getName().charAt(0)).toUpperCase();
  %>
    <div class="contact-card">
      <div class="avatar"><%= initial %></div>
      <div class="contact-info">
        <div class="name">
          <%= c.getName() %>
          <span class="cat-badge"><%= c.getCategory() %></span>
        </div>
        <div class="detail">&#128222; <%= c.getPhone() %></div>
        <% if (c.getEmail() != null && !c.getEmail().isEmpty()) { %>
          <div class="detail">&#9993; <%= c.getEmail() %></div>
        <% } %>
      </div>
      <div class="contact-actions">
        <a class="btn btn-danger btn-sm"
           href="${pageContext.request.contextPath}/deleteContact?id=<%= c.getId() %>"
           onclick="return confirm('Delete this contact?')">
          &#128465; Delete
        </a>
      </div>
    </div>
  <%
      }
    }
  %>

</div>

</body>
</html>
