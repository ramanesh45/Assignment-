<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Add Contact - Contact Manager</title>
  <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<nav>
  <div class="logo">&#128203; Contact<span>Manager</span></div>
  <div>
    <a class="btn btn-outline btn-sm" href="${pageContext.request.contextPath}/">Home</a>
    <a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/viewContacts">All Contacts</a>
  </div>
</nav>

<div class="form-card">
  <h2>&#10133; Add New Contact</h2>

  <form action="${pageContext.request.contextPath}/addContact" method="post">

    <div class="form-group">
      <label for="name">Full Name *</label>
      <input type="text" id="name" name="name" placeholder="e.g. Ramanesh Kumar" required/>
    </div>

    <div class="form-group">
      <label for="phone">Phone Number *</label>
      <input type="tel" id="phone" name="phone" placeholder="e.g. 9876543210" required/>
    </div>

    <div class="form-group">
      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" placeholder="e.g. ramanesh@email.com"/>
    </div>

    <div class="form-group">
      <label for="category">Category</label>
      <select id="category" name="category">
        <option value="Personal">Personal</option>
        <option value="Work">Work</option>
        <option value="Family">Family</option>
        <option value="Other">Other</option>
      </select>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary">Save Contact</button>
      <a class="btn btn-outline" href="${pageContext.request.contextPath}/">Cancel</a>
    </div>

  </form>
</div>

</body>
</html>
