<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Manager</title>
  <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<nav>
  <div class="logo">&#128203; Contact<span>Manager</span></div>
  <div>
    <a class="btn btn-outline btn-sm" href="${pageContext.request.contextPath}/">Home</a>
    <a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/viewContacts">All Contacts</a>
  </div>
</nav>

<div class="welcome">
  <div class="icon">&#128101;</div>
  <h1>Welcome to Contact Manager</h1>
  <p>Manage your contacts efficiently in one place. Add, view, and organize your personal and professional contacts with ease.</p>
  <div class="btn-group">
    <a class="btn btn-primary" href="${pageContext.request.contextPath}/addContact">&#10133; Add Contact</a>
    <a class="btn btn-secondary" href="${pageContext.request.contextPath}/viewContacts">&#128203; View All Contacts</a>
  </div>
</div>

</body>
</html>
